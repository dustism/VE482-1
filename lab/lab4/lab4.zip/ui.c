#include "interface.h"

int main(int argc, char *argv[]) {
    return dispatch_ui(argc, argv);
}