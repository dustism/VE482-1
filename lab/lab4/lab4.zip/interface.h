//
// Created by liu on 2017/10/20.
//

#ifndef PROJECT_INTERFACE_H
#define PROJECT_INTERFACE_H

int dispatch_cli(int argc, char *argv[]);

int dispatch_ui(int argc, char *argv[]);

#endif //PROJECT_INTERFACE_H
